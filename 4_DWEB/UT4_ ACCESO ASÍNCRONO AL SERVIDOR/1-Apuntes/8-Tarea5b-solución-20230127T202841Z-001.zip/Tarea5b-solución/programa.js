var Programa = /** @class */ (function () {
    function Programa() {
    }
    Programa.prototype.getNombre = function () {
        return this.nombre;
    };
    Programa.prototype.setNombre = function (nombre) {
        this.nombre = nombre;
    };
    Programa.prototype.getVersion = function () {
        return this.version;
    };
    Programa.prototype.setVersion = function (version) {
        this.version = version;
    };
    return Programa;
}());
var button = document.getElementById("btnGuardar");
button.addEventListener("click", addPrograma);
function addPrograma() {
    var programa = new Programa();
    var nombrePrograma = document.getElementsByTagName("input")[0].value;
    //let inputNombre = <HTMLInputElement>document.getElementById("nombre");
    //let nombrePrograma:string = inputNombre.value;
    programa.setNombre(nombrePrograma);
    var info = document.getElementById("container");
    info.innerHTML += "<li>" + programa.getNombre() + "</li>";
    document.getElementsByTagName("input")[0].value = "";
    //inputNombre.value="";
}
