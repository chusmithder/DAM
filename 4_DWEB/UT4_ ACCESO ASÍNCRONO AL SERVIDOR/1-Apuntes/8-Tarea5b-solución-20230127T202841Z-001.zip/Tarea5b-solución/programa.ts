class Programa{
    public nombre:string;
    public version:string;

    public getNombre():string{
        return this.nombre;
    }

    public setNombre(nombre:string){
        this.nombre = nombre;
    }

    public getVersion():string{
        return this.version;
    }

    public setVersion(version:string){
        this.version = version;
    }
}



var button = document.getElementById("btnGuardar");
button.addEventListener("click", addPrograma);

function addPrograma(){
    let programa = new Programa();
    let nombrePrograma=document.getElementsByTagName("input")[0].value
    //let inputNombre = <HTMLInputElement>document.getElementById("nombre");
    //let nombrePrograma:string = inputNombre.value;
    programa.setNombre(nombrePrograma);
    let info = <HTMLElement>document.getElementById("container");
    info.innerHTML += "<li>" + programa.getNombre() + "</li>"
    document.getElementsByTagName("input")[0].value="";
    //inputNombre.value="";
}