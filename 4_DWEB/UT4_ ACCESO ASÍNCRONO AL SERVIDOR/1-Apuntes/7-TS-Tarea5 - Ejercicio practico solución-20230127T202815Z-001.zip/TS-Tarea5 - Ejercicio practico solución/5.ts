class Programa
{
    constructor(public nombre:string, public version:number)
    {
        this.nombre = nombre;
    }
    getNombre():string
    {
        return this.nombre;
    }
    getVersion():number
    {
        return this.version;
    }
}
let programas:Programa[] = [];

function addProgram()
{
    let a= <HTMLInputElement>document.getElementById("textInput");
    programas.push(new Programa(a.value, 1.0));
    document.getElementById("demo")!.innerHTML += "<li>" + programas[programas.length-1].getNombre() + "</li>";
    a.value="";
}