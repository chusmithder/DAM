var Programa = /** @class */ (function () {
    function Programa(nombre, version) {
        this.nombre = nombre;
        this.version = version;
        this.nombre = nombre;
    }
    Programa.prototype.getNombre = function () {
        return this.nombre;
    };
    Programa.prototype.getVersion = function () {
        return this.version;
    };
    return Programa;
}());
var programas = [];
function addProgram() {
    var a = document.getElementById("textInput");
    programas.push(new Programa(a.value, 1.0));
    document.getElementById("demo").innerHTML += "<li>" + programas[programas.length - 1].getNombre() + "</li>";
    a.value = "";
}
