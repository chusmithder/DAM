package historico.modelo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 *
 *  La clase guarda en una colecci�n map el hist�rico de puntuaciones obtenidas
 *  por una serie de jugadores en varias partidas de un juego
 *  La colecci�n asocia el nombre de un jugador (la clave) con la relaci�n
 *  de puntuaciones obtenidas por ese jugador (valores enteros)
 *
 *  Por ejemplo, para la clave "ANTIGOAL" se asocian los valores [44, 44,
 *  125, 89, 23, 12, 78, 89]
 *  que son los puntos obtenidos por ese jugador en 7 partidas
 *
 *  Las claves se recuperan en orden alfab�tico. Los puntos asociados a cada
 *  jugador se recuperan en el orden en que se introducen 
 *
 */

public class Historico {
    private TreeMap<String, ArrayList<Integer>> historico;
    
    /**
     * Constructor de objetos de la clase Historico
     */
    public Historico() {
        historico = new TreeMap<>();
    }
    
    /**
     * Se registra en el map los puntos obtenidos por el
     * jugador en una partida 
     * Si el jugador ya existe �nicamente solo hay que a�adir
     * la nueva puntuaci�n a las ya existentes
     * Si no existe se crear� una nueva entrada con el nombre del jugador
     * y los puntos indicados 
     *
     * Las claves  siempre se a�aden en may�sculas 
     *
     */
    public void registrarPuntos(String jugador, int puntos) {
        jugador = jugador.toUpperCase();
        if (historico.containsKey(jugador)) {
            historico.get(jugador).add(puntos);
            
        } else {
            ArrayList<Integer> puntuaciones = new ArrayList<>();
            puntuaciones.add(puntos);
            historico.put(jugador, puntuaciones);
        }
        
    }
    
    /**
     * Devuelve una representaci�n textual del map con
     * los nombres de los jugadores y la relaci�n de puntos obtenidos
     * (leer enunciado)
     * En la representaci�n textual observa que las puntuaciones est�n ordenadas
     * (pero la colecci�n original no se modifica)
     *
     *
     * Usar el conjunto de entradas 
     * De forma eficiente ya que hay muchas concatenaciones
     *
     */
    public String toString() {
        StringBuilder sb = new StringBuilder("Relaci�n de jugadores y " +
                "puntuaciones\n");
        Set<Map.Entry<String, ArrayList<Integer>>> conjuntoEntradas =
                historico.entrySet();
        for (Map.Entry<String, ArrayList<Integer>> entrada : conjuntoEntradas) {
            ArrayList<Integer> copia = new ArrayList<>(entrada.getValue());
            Collections.sort(copia);
            sb.append(entrada.getKey() + " (" + copia.size() + " partidas)" +
                    "\n\t");
            sb.append(copia.toString() + "\n");
        }
        
        return sb.toString();
    }
    
    /**
     *  Dado un jugador se devuelve su puntuaci�n media
     *  Si no existe el jugador el valor devuelto es -1
     *
     */
    public double puntuacionMediaDe(String jugador) {
        jugador = jugador.toUpperCase();
        if (!historico.containsKey(jugador)) {
            return -1;
            
        }
        ArrayList<Integer> puntuaciones = historico.get(jugador);
        int suma = 0;
        for (int puntos : puntuaciones) {
            suma += puntos;
        }
        return (double) suma / puntuaciones.size();
    }
    
    
    /**
     * Devuelve una colecci�n que asocia nombres
     * de jugadores y su puntuaci�n media
     * No importa el orden en que se obtengan los nombres
     * de jugadores
     *
     */
    public HashMap<String, Double> puntuacionesMedias() {
        HashMap<String, Double> mapMedias = new HashMap<>();
        for (String jugador : historico.keySet()) {
            mapMedias.put(jugador, puntuacionMediaDe(jugador));
        }
        
        return mapMedias;
        
    }
    
    
    /**
     *  Hay que borrar de las entradas correspondientes a los jugadores
     *  indicados
     *  aquellas puntuaciones menores a la proporcionada.
     *  Si despu�s de borrar el jugador no tiene puntos asociados se elimina
     *  la entrada
     *  del map. El m�todo devuelve el conjunto (no importa el orden) de
     *  jugadores cuyas entradas se han eliminado
     *
     *  Asumimos que los jugadores existen (no hay que comprobarlo)
     *
     *
     */
    public HashSet<String> borrarMenoresA(String[] jugadores, int puntos) {
        HashSet<String> borradas = new HashSet<>();
        for (String jugador : jugadores) {
	    jugador = jugador.toUpperCase()
            ArrayList<Integer> puntuaciones = historico.get(jugador);
            Iterator<Integer> it = puntuaciones.iterator();
            while (it.hasNext()) {
                Integer i = it.next();
                if (i < puntos) {
                    it.remove();
                }
            }
            if (puntuaciones.isEmpty()) {
                borradas.add(jugador);
                historico.remove(jugador);
            }
        }

        return borradas;
    }
    
    
    /**
     *  Lee de un fichero de texto los datos de las jugadores y puntuaciones
     *  obtenidas y los a�ade al map
     */
    public void leerPuntuacionesDeFichero() {
        
        Scanner sc = null;
        try {
            sc = new Scanner(this.getClass().getResourceAsStream("/puntos" +
                    ".txt"));
            while (sc.hasNext()) {
                String linea = sc.nextLine().trim();
                String[] datos = linea.trim().split(":");
                for (String strPuntos : Arrays.copyOfRange(datos, 1,
                        datos.length)) {
                    this.registrarPuntos(datos[0].trim(),
                            Integer.parseInt(strPuntos.trim()));
                }
                
            }
        } finally {
            sc.close();
            
        }
        
    }
}
