﻿
/**
 * Una colección TreeMap que asocia nombres de alumno y nota obtenida
 */

public class MapCurso {
	private String nombre;
	private TreeMap<String, Integer> mapCurso;

	/**
	 * Constructor
	 */
	public MapCurso() {

	}

	/**
	 * Añadir una nueva entrada al map, la clave es el nombre, el valor asociado
	 * la nota
	 * 
	 */
	public void add(String alumno, int nota) {

	}

	/**
	 * Dado un alumno obtener su nota si no existe el alumno se devuelve -1
	 */

	// public int notaDe(String alumno)
	// {
	//
	// }

	/**
	 * Mostrar cada alumno junto a su nota conjunto de entradas y for
	 */
	public void mostrarCurso() {

	}

	/**
	 * calcula y devuelve un map donde las claves son ahora las diferentes notas
	 * y cada clave se asocia con la lista de alumnos que han obtenido esa nota
	 */

	// public TreeMap<Integer, ArrayList<String>> obtenerEstadisticas()
	// {
	//
	// }

}
