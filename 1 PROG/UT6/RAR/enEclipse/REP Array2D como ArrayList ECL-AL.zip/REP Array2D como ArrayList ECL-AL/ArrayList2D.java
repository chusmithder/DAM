import java.util.ArrayList;

/**
 * Un ArrayList es un colección que guarda objetos de un determinado tipo.
 * Este tipo puede ser también un ArrayList. 
 * En este ejercicio construiremos un array
 * de 2 dimensiones de 10 filas y 10 columnas usando colecciones ArrayList
 * 
 * !!NO USAR SIEMPRE FOR MEJORADO, en este ejemplo a veces será mejor usar for con índices!!
 */
public class ArrayList2D {
	private ArrayList<ArrayList<Integer>> lista2D;

	/**
	 * Constructor
	 * Instancia la colección lista2d creándola con una capacidad
	 * inicial de 10 elementos Usa el constructor adecuado 
	 * Llama al método privado inicializar()
	 */
	public ArrayList2D() {

	}

	/**
	 * Crea cada una de las 10 filas guardando en ellas valores aleatorios entre
	 * 1 y 10 (inclusive) 
	 * Usar clase random (defínela previamente como atributo
	 * estático
	 */
	private void inicializar() {

	}

	/**
	 * Devuelve la cantidad de filas de la matriz (no uses el valor 10)
	 *
	 */
	public int getFilas() {
		return 0;
	}

	/**
	 * Devuelve la cantidad de columnasas de la matriz (no uses el valor 10)
	 *
	 */
	public int getColumnas() {
		return 0;
	}

	/**
	 * Dado un nº de fila devuelve su suma 
	 * Si el nº de fila es incorrecto se
	 * lanza la excepción IllegalArgumentException
	 * con el mensaje "Argumento fila incorrecto"
	 *
	 */
	public int sumaDeFila(int f) {
		return 0;

	}

	/**
	 * Dado un nº de columna devuelve su suma Si el nº de columna es incorrecto
	 * se lanza la excepción IllegalArgumentException con el mensaje
	 * "Argumento columna incorrecto"
	 *
	 */
	public int sumaDeColumna(int c) {

		return 0;
	}

	/**
	 * Este sí con bucles for mejorado
	 * Cada nº en un espacio de 5 posiciones en la
	 * pantalla
	 *
	 */
	public void mostrar() {

	}

	/**
	 * borrar todos los pares que hay en las filas 
	 * 
	 * !!AVANZADOS!!
	 * 
	 * Si al borrar alguna fila queda vacía se borra también
	 * 
	 */
	public void borraPares() {
	}
}
