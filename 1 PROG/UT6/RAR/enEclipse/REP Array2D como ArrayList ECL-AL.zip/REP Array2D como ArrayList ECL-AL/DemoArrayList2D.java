public class DemoArrayList2D {

	/**
	 * Punto de entrada a la aplicación
	 *
	 */
	public static void main(String[] args) {

		ArrayList2D lista = new ArrayList2D();
		lista.mostrar();
		int f = 6;
		System.out.println(
				"\nLa suma de la fila " + f + " es " + lista.sumaDeFila(f));
		int c = 8;
		System.out.println(
				"La suma de la columna " + c + " es " + lista.sumaDeColumna(c));

		System.out.println("Después de borrar los valores pares de las filas");
		lista.borraPares();
		lista.mostrar();

	}

}
